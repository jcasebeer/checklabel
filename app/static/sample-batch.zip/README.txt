Label Check — sample batch
==========================

Real alcohol beverage labels from the TTB Public COLA Registry, with a
manifest of the expected values from their approved applications.
'tx' is a multi-panel label (front + back) checked as one.

Submit against a running instance:

  curl -X POST http://localhost:8000/batch \
    -F 'manifest=<manifest.json' \
    -F 'files=@barolo-chinato.jpg' -F 'files=@alvides.jpg' -F 'files=@tx-panel1.jpg' -F 'files=@tx-panel2.jpg'

Add  -F 'mode=queued'  to run it through the Message Batches API instead
(half token cost; poll the returned results_url).
